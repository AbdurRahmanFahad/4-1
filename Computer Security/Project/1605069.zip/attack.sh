gcc -o out 1605069.c
sudo ./out habijabiquery.com 192.168.0.112